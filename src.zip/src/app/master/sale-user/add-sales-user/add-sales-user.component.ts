import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-sales-user',
  templateUrl: './add-sales-user.component.html'
})
export class AddSalesUserComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
